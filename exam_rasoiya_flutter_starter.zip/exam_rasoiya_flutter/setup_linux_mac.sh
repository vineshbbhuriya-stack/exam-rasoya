#!/usr/bin/env bash
set -e

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter command not found. Install Flutter SDK and add it to PATH."
  exit 1
fi

rm -rf .exam_backup
mkdir -p .exam_backup
cp -R lib .exam_backup/lib
cp pubspec.yaml .exam_backup/pubspec.yaml
cp analysis_options.yaml .exam_backup/analysis_options.yaml

flutter create --platforms=android .

rm -rf lib
cp -R .exam_backup/lib lib
cp .exam_backup/pubspec.yaml pubspec.yaml
cp .exam_backup/analysis_options.yaml analysis_options.yaml
rm -rf .exam_backup

flutter pub get

echo "Setup complete."
echo "Run: flutter run"
echo "Build APK: flutter build apk --release"
