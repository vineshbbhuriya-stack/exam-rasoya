class Question {
  const Question({
    required this.subject,
    required this.text,
    required this.options,
    required this.answerIndex,
    required this.explanation,
  });

  final String subject;
  final String text;
  final List<String> options;
  final int answerIndex;
  final String explanation;
}
