import 'package:flutter/material.dart';

import '../data/sample_questions.dart';
import '../models/question.dart';
import 'quiz_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({
    super.key,
    required this.studentName,
  });

  final String studentName;

  static const Map<String, IconData> _subjectIcons = {
    'કમ્પ્યુટર': Icons.computer_rounded,
    'ગુજરાત સામાન્ય જ્ઞાન': Icons.public_rounded,
    'રોડ સેફ્ટી': Icons.traffic_rounded,
    'પ્રાથમિક સારવાર': Icons.medical_services_rounded,
    'ગણિત': Icons.calculate_rounded,
    'રિઝનિંગ': Icons.psychology_alt_rounded,
    'ગુજરાતી વ્યાકરણ': Icons.translate_rounded,
    'English Grammar': Icons.language_rounded,
  };

  void _openQuiz(
    BuildContext context, {
    required String title,
    required List<Question> questions,
  }) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => QuizScreen(
          quizTitle: title,
          questions: questions,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final subjects = sampleQuestions.map((q) => q.subject).toSet().toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Exam રસોયા',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        actions: [
          IconButton(
            tooltip: 'સૂચના',
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('હાલ કોઈ નવી સૂચના નથી.'),
                ),
              );
            },
            icon: const Icon(Icons.notifications_none_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF08783E), Color(0xFF14A05A)],
                ),
                borderRadius: BorderRadius.circular(22),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'નમસ્તે, $studentName 👋',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 23,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 7),
                  const Text(
                    'આજની તૈયારી પૂર્ણ કરો અને તમારો સ્કોર સુધારો.',
                    style: TextStyle(
                      color: Color(0xFFE2FFEA),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: const Color(0xFF08783E),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      onPressed: () => _openQuiz(
                        context,
                        title: 'ફુલ મોક ટેસ્ટ',
                        questions: sampleQuestions,
                      ),
                      icon: const Icon(Icons.play_circle_fill_rounded),
                      label: Text(
                        'ફુલ મોક ટેસ્ટ શરૂ કરો (${sampleQuestions.length} પ્રશ્ન)',
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'વિષયવાર ક્વિઝ',
              style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 12),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: subjects.length,
              gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                maxCrossAxisExtent: 230,
                mainAxisExtent: 150,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
              ),
              itemBuilder: (context, index) {
                final subject = subjects[index];
                final questions = sampleQuestions
                    .where((q) => q.subject == subject)
                    .toList();

                return Card(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(18),
                    onTap: () => _openQuiz(
                      context,
                      title: subject,
                      questions: questions,
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CircleAvatar(
                            radius: 24,
                            backgroundColor:
                                const Color(0xFFE2F7E9),
                            child: Icon(
                              _subjectIcons[subject] ?? Icons.quiz_rounded,
                              color: const Color(0xFF08783E),
                            ),
                          ),
                          const Spacer(),
                          Text(
                            subject,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${questions.length} પ્રશ્ન',
                            style: const TextStyle(
                              color: Colors.black54,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 20),
            Card(
              child: ListTile(
                contentPadding: const EdgeInsets.all(14),
                leading: const CircleAvatar(
                  backgroundColor: Color(0xFFFFF3D8),
                  child: Icon(
                    Icons.workspace_premium_rounded,
                    color: Color(0xFFB86D00),
                  ),
                ),
                title: const Text(
                  'Premium Course',
                  style: TextStyle(fontWeight: FontWeight.w900),
                ),
                subtitle: const Text(
                  'Daily 100 MCQ, PDF Notes અને Mock Test માટે સ્થાન તૈયાર છે.',
                ),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Premium Payment અને Course Lock આગળના વર્ઝનમાં જોડાશે.',
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
