import 'dart:async';

import 'package:flutter/material.dart';

import '../models/question.dart';
import 'result_screen.dart';

class QuizScreen extends StatefulWidget {
  const QuizScreen({
    super.key,
    required this.quizTitle,
    required this.questions,
  });

  final String quizTitle;
  final List<Question> questions;

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  late final List<int?> _answers;
  Timer? _timer;
  int _currentIndex = 0;
  int? _selectedIndex;
  late int _secondsLeft;

  @override
  void initState() {
    super.initState();
    _answers = List<int?>.filled(widget.questions.length, null);
    _secondsLeft = widget.questions.length * 60;
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (_secondsLeft <= 1) {
        setState(() => _secondsLeft = 0);
        _finishQuiz();
      } else {
        setState(() => _secondsLeft--);
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String get _timeText {
    final minutes = _secondsLeft ~/ 60;
    final seconds = _secondsLeft % 60;
    return '${minutes.toString().padLeft(2, '0')}:'
        '${seconds.toString().padLeft(2, '0')}';
  }

  void _saveCurrentAnswer() {
    _answers[_currentIndex] = _selectedIndex;
  }

  void _goToQuestion(int index) {
    _saveCurrentAnswer();
    setState(() {
      _currentIndex = index;
      _selectedIndex = _answers[index];
    });
  }

  void _next() {
    _saveCurrentAnswer();

    if (_currentIndex == widget.questions.length - 1) {
      _confirmFinish();
      return;
    }

    setState(() {
      _currentIndex++;
      _selectedIndex = _answers[_currentIndex];
    });
  }

  void _previous() {
    if (_currentIndex == 0) return;
    _saveCurrentAnswer();
    setState(() {
      _currentIndex--;
      _selectedIndex = _answers[_currentIndex];
    });
  }

  Future<void> _confirmFinish() async {
    final unanswered = _answers.where((answer) => answer == null).length;
    final shouldFinish = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('ક્વિઝ પૂર્ણ કરવી છે?'),
        content: Text(
          unanswered == 0
              ? 'તમામ પ્રશ્નોના જવાબ આપવામાં આવ્યા છે.'
              : '$unanswered પ્રશ્ન હજુ બાકી છે.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('પાછા જાઓ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('સબમિટ કરો'),
          ),
        ],
      ),
    );

    if (shouldFinish == true) {
      _finishQuiz();
    }
  }

  void _finishQuiz() {
    _timer?.cancel();
    _saveCurrentAnswer();

    if (!mounted) return;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(
        builder: (_) => ResultScreen(
          quizTitle: widget.quizTitle,
          questions: widget.questions,
          answers: _answers,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final question = widget.questions[_currentIndex];
    final progress = (_currentIndex + 1) / widget.questions.length;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.quizTitle,
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 12, top: 10, bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: _secondsLeft < 60
                  ? const Color(0xFFC62828)
                  : const Color(0x26FFFFFF),
              borderRadius: BorderRadius.circular(20),
            ),
            alignment: Alignment.center,
            child: Row(
              children: [
                const Icon(Icons.timer_outlined, size: 18),
                const SizedBox(width: 5),
                Text(
                  _timeText,
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
              ],
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            LinearProgressIndicator(
              value: progress,
              minHeight: 6,
              backgroundColor: const Color(0xFFD7EBDD),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Row(
                    children: [
                      Text(
                        'પ્રશ્ન ${_currentIndex + 1}/${widget.questions.length}',
                        style: const TextStyle(
                          color: Color(0xFF08783E),
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const Spacer(),
                      Chip(
                        label: Text(question.subject),
                        visualDensity: VisualDensity.compact,
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Text(
                        question.text,
                        style: const TextStyle(
                          fontSize: 20,
                          height: 1.45,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  ...List.generate(question.options.length, (index) {
                    final isSelected = _selectedIndex == index;
                    final optionLetter = String.fromCharCode(65 + index);

                    return Padding(
                      padding: const EdgeInsets.only(bottom: 11),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => setState(() => _selectedIndex = index),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          padding: const EdgeInsets.all(15),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? const Color(0xFFE1F6E8)
                                : Colors.white,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: isSelected
                                  ? const Color(0xFF08783E)
                                  : const Color(0xFFD7EBDD),
                              width: isSelected ? 2 : 1,
                            ),
                          ),
                          child: Row(
                            children: [
                              CircleAvatar(
                                radius: 18,
                                backgroundColor: isSelected
                                    ? const Color(0xFF08783E)
                                    : const Color(0xFFF0F4F1),
                                foregroundColor:
                                    isSelected ? Colors.white : Colors.black87,
                                child: Text(
                                  optionLetter,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  question.options[index],
                                  style: TextStyle(
                                    fontSize: 16,
                                    height: 1.35,
                                    fontWeight: isSelected
                                        ? FontWeight.w800
                                        : FontWeight.w600,
                                  ),
                                ),
                              ),
                              if (isSelected)
                                const Icon(
                                  Icons.check_circle_rounded,
                                  color: Color(0xFF08783E),
                                ),
                            ],
                          ),
                        ),
                      ),
                    );
                  }),
                  const SizedBox(height: 8),
                  const Text(
                    'પ્રશ્ન પસંદગી',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: List.generate(widget.questions.length, (index) {
                      final isCurrent = index == _currentIndex;
                      final answered = _answers[index] != null ||
                          (isCurrent && _selectedIndex != null);

                      return InkWell(
                        borderRadius: BorderRadius.circular(10),
                        onTap: () => _goToQuestion(index),
                        child: Container(
                          width: 40,
                          height: 40,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: isCurrent
                                ? const Color(0xFF08783E)
                                : answered
                                    ? const Color(0xFFDDF4E5)
                                    : Colors.white,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: isCurrent || answered
                                  ? const Color(0xFF08783E)
                                  : const Color(0xFFD7EBDD),
                            ),
                          ),
                          child: Text(
                            '${index + 1}',
                            style: TextStyle(
                              color: isCurrent ? Colors.white : Colors.black87,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      );
                    }),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
              decoration: const BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Color(0x16000000),
                    blurRadius: 12,
                    offset: Offset(0, -3),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _currentIndex == 0 ? null : _previous,
                      icon: const Icon(Icons.arrow_back_rounded),
                      label: const Text('પાછળ'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: FilledButton.icon(
                      onPressed: _next,
                      icon: Icon(
                        _currentIndex == widget.questions.length - 1
                            ? Icons.check_circle_outline_rounded
                            : Icons.arrow_forward_rounded,
                      ),
                      label: Text(
                        _currentIndex == widget.questions.length - 1
                            ? 'સબમિટ'
                            : 'આગળ',
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
