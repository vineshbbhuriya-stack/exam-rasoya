import 'package:flutter/material.dart';

import '../models/question.dart';

class ResultScreen extends StatelessWidget {
  const ResultScreen({
    super.key,
    required this.quizTitle,
    required this.questions,
    required this.answers,
  });

  final String quizTitle;
  final List<Question> questions;
  final List<int?> answers;

  int get correctCount {
    var count = 0;
    for (var i = 0; i < questions.length; i++) {
      if (answers[i] == questions[i].answerIndex) count++;
    }
    return count;
  }

  int get unansweredCount => answers.where((answer) => answer == null).length;

  int get wrongCount => questions.length - correctCount - unansweredCount;

  double get score => correctCount - (wrongCount * 0.25);

  double get percentage {
    if (questions.isEmpty) return 0;
    return (correctCount / questions.length) * 100;
  }

  String get performanceMessage {
    if (percentage >= 80) return 'ઉત્તમ પ્રદર્શન!';
    if (percentage >= 60) return 'સારું પ્રદર્શન!';
    if (percentage >= 40) return 'વધુ પ્રેક્ટિસ કરો.';
    return 'ફરી તૈયારી કરીને પ્રયાસ કરો.';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text(
          'ક્વિઝ પરિણામ',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF08783E), Color(0xFF14A05A)],
                ),
                borderRadius: BorderRadius.circular(22),
              ),
              child: Column(
                children: [
                  const Icon(
                    Icons.emoji_events_rounded,
                    size: 62,
                    color: Color(0xFFFFD85A),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    performanceMessage,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 25,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    quizTitle,
                    style: const TextStyle(
                      color: Color(0xFFE2FFEA),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    score.toStringAsFixed(2),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 42,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  Text(
                    'કુલ ${questions.length} ગુણમાંથી',
                    style: const TextStyle(color: Color(0xFFE2FFEA)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _StatCard(
                    label: 'સાચા',
                    value: '$correctCount',
                    icon: Icons.check_circle_rounded,
                    iconColor: const Color(0xFF14833B),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _StatCard(
                    label: 'ખોટા',
                    value: '$wrongCount',
                    icon: Icons.cancel_rounded,
                    iconColor: const Color(0xFFC62828),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _StatCard(
                    label: 'બાકી',
                    value: '$unansweredCount',
                    icon: Icons.help_rounded,
                    iconColor: const Color(0xFFEF8A00),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    const Icon(
                      Icons.info_outline_rounded,
                      color: Color(0xFF08783E),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Negative Marking: દરેક ખોટા જવાબ માટે 0.25 ગુણ કપાયા છે. ચોકસાઈ: ${percentage.toStringAsFixed(1)}%',
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          height: 1.4,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 22),
            const Text(
              'જવાબ સમીક્ષા',
              style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 10),
            ...List.generate(questions.length, (index) {
              final question = questions[index];
              final selected = answers[index];
              final isCorrect = selected == question.answerIndex;

              return Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Card(
                  child: ExpansionTile(
                    tilePadding: const EdgeInsets.symmetric(
                      horizontal: 15,
                      vertical: 5,
                    ),
                    leading: CircleAvatar(
                      backgroundColor: selected == null
                          ? const Color(0xFFFFF3D8)
                          : isCorrect
                              ? const Color(0xFFDDF4E5)
                              : const Color(0xFFFFE0E0),
                      child: Icon(
                        selected == null
                            ? Icons.help_outline_rounded
                            : isCorrect
                                ? Icons.check_rounded
                                : Icons.close_rounded,
                        color: selected == null
                            ? const Color(0xFFEF8A00)
                            : isCorrect
                                ? const Color(0xFF14833B)
                                : const Color(0xFFC62828),
                      ),
                    ),
                    title: Text(
                      '${index + 1}. ${question.text}',
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            if (selected == null)
                              const Text(
                                'તમારો જવાબ: આપ્યો નથી',
                                style: TextStyle(
                                  color: Color(0xFFEF8A00),
                                  fontWeight: FontWeight.w800,
                                ),
                              )
                            else
                              Text(
                                'તમારો જવાબ: ${question.options[selected]}',
                                style: TextStyle(
                                  color: isCorrect
                                      ? const Color(0xFF14833B)
                                      : const Color(0xFFC62828),
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            const SizedBox(height: 7),
                            Text(
                              'સાચો જવાબ: ${question.options[question.answerIndex]}',
                              style: const TextStyle(
                                color: Color(0xFF14833B),
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 9),
                            Text(
                              question.explanation,
                              style: const TextStyle(height: 1.4),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: () => Navigator.of(context).pop(),
              icon: const Icon(Icons.home_rounded),
              label: const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: Text(
                  'હોમ પેજ પર જાઓ',
                  style: TextStyle(fontWeight: FontWeight.w900),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.iconColor,
  });

  final String label;
  final String value;
  final IconData icon;
  final Color iconColor;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 8),
        child: Column(
          children: [
            Icon(icon, color: iconColor),
            const SizedBox(height: 5),
            Text(
              value,
              style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900),
            ),
            Text(
              label,
              style: const TextStyle(
                color: Colors.black54,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
