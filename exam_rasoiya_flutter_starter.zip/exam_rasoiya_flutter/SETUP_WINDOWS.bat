@echo off
setlocal

echo ==========================================
echo Exam Rasoiya Flutter Android Setup
echo ==========================================

where flutter >nul 2>nul
if errorlevel 1 (
  echo.
  echo ERROR: Flutter command not found.
  echo Flutter SDK install kari PATH ma add karo.
  pause
  exit /b 1
)

if exist "_exam_backup" rmdir /s /q "_exam_backup"
mkdir "_exam_backup"

xcopy "lib" "_exam_backup\lib\" /E /I /Y >nul
copy "pubspec.yaml" "_exam_backup\pubspec.yaml" >nul
copy "analysis_options.yaml" "_exam_backup\analysis_options.yaml" >nul

echo.
echo Android project files banavi rahya chhiye...
call flutter create --platforms=android .

if errorlevel 1 (
  echo.
  echo ERROR: flutter create failed.
  pause
  exit /b 1
)

if exist "lib" rmdir /s /q "lib"
xcopy "_exam_backup\lib" "lib\" /E /I /Y >nul
copy "_exam_backup\pubspec.yaml" "pubspec.yaml" /Y >nul
copy "_exam_backup\analysis_options.yaml" "analysis_options.yaml" /Y >nul
rmdir /s /q "_exam_backup"

echo.
echo Packages download kari rahya chhiye...
call flutter pub get

if errorlevel 1 (
  echo.
  echo ERROR: flutter pub get failed.
  pause
  exit /b 1
)

echo.
echo ==========================================
echo Setup complete.
echo Android Studio ma aa folder kholo.
echo App chalava: flutter run
echo APK banava: flutter build apk --release
echo ==========================================
pause
