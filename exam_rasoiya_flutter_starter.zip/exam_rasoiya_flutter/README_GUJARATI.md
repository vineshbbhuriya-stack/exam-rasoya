# Exam રસોયા – Flutter Quiz App

આ Flutter Starter Appમાં નીચેની સુવિધાઓ તૈયાર છે:

- Splash Screen
- વિદ્યાર્થીનું નામ અને મોબાઇલ નંબર Login
- ગુજરાતી Mobile Friendly UI
- વિષયવાર Quiz
- Full Mock Test
- કુલ સમયનું Countdown Timer
- પ્રશ્ન નંબર Palette
- Negative Marking: ખોટા જવાબ દીઠ -0.25
- Result Summary
- સાચા જવાબ અને સમજૂતી સાથે Review
- કોઈ External Package વગર સરળ Setup

## Windowsમાં પ્રથમ વખત Setup

1. Flutter SDK અને Android Studio ઇન્સ્ટોલ હોવા જોઈએ.
2. ZIP Extract કરો.
3. Extract કરેલા Folderમાં `SETUP_WINDOWS.bat` પર Double Click કરો.
4. Android Studioમાં Folder ખોલો.
5. મોબાઇલમાં USB Debugging ચાલુ કરીને Run દબાવો.

અથવા Terminalમાં:

```bash
flutter create --platforms=android .
flutter pub get
flutter run
```

નોંધ: `flutter create` ચલાવતી વખતે `lib` Folderની Copy રાખવી સારી છે. આપેલી Windows Setup File આ Backup અને Restore આપમેળે કરે છે.

## APK બનાવવાની રીત

```bash
flutter build apk --release
```

APK અહીં મળશે:

```text
build/app/outputs/flutter-apk/app-release.apk
```

## Appમાં નવા પ્રશ્નો ઉમેરવા

`lib/data/sample_questions.dart` ફાઇલમાં આ Pattern મુજબ પ્રશ્ન ઉમેરો:

```dart
Question(
  subject: 'વિષય',
  text: 'પ્રશ્ન',
  options: ['વિકલ્પ 1', 'વિકલ્પ 2', 'વિકલ્પ 3', 'વિકલ્પ 4'],
  answerIndex: 0,
  explanation: 'સમજૂતી',
),
```

`answerIndex`માં:
- પ્રથમ વિકલ્પ માટે `0`
- બીજા વિકલ્પ માટે `1`
- ત્રીજા વિકલ્પ માટે `2`
- ચોથા વિકલ્પ માટે `3`

## હાલમાં રહેલા Demo વિષયો

- કમ્પ્યુટર
- ગુજરાત સામાન્ય જ્ઞાન
- રોડ સેફ્ટી
- પ્રાથમિક સારવાર
- ગણિત
- રિઝનિંગ
- ગુજરાતી વ્યાકરણ
- English Grammar

## આગળના Production Versionમાં ઉમેરવા યોગ્ય સુવિધાઓ

- Firebase OTP Login અને Database
- Admin Panelથી Daily 100 MCQ Update
- GSRTC Driver / Conductor / MPHW / FHW અલગ Courses
- PDF Notes અને Download Protection
- Premium Course Lock
- UPI Payment
- Push Notification
- Online Leaderboard
- એક મોબાઇલ નંબર પર એક Device Login
- Telegram અને WhatsApp Link
